﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _20._03._2024_Task02o_Mulov_Sevostyanov
{
    public partial class Form_Main : Form
    {
        int flag =-1;
        Graphics g;
        public Form_Main()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            g = this.pictureBox1.CreateGraphics();
            Brush brush = new SolidBrush(Color.MediumAquamarine);
            Pen pen = new Pen(Color.MediumAquamarine,4);
            switch(flag)
                {
                case -1:
                    MessageBox.Show("Выберите какое-нибудь значение");
                    break;
                case 9:
                    g.FillEllipse(brush, 80, 80, 40, 40);
                    break;
                case 1:
                    PointF point1 = new PointF(70, 50);
                    PointF point2 = new PointF(40, 50);
                    PointF point3 = new PointF(10, 100);
                    PointF point4 = new PointF(100, 100);
                    PointF[] Trapecia = { point1, point2, point3, point4};
                    g.FillPolygon(brush, Trapecia);
                    break;
                case 12:
                    PointF point5 = new PointF(70, 50);
                    PointF point6 = new PointF(20, 50);
                    PointF point7 = new PointF(20, 100);
                    PointF point8 = new PointF(70, 100);
                    PointF[] Sqware= { point5, point6, point7, point8};
                    g.FillPolygon(brush, Sqware);
                    break;
                case 8:
                    PointF point9 = new PointF(100, 200);
                    PointF point10 = new PointF(200, 100);
                    PointF point11 = new PointF(100, 100);
                    PointF[] Ravnobedr_Tiangle = { point9, point10, point11};
                    g.FillPolygon(brush, Ravnobedr_Tiangle);
                    break;
                case 6:
                    PointF point12 = new PointF(0, 0);
                    PointF point13 = new PointF(100, 173);
                    PointF point14 = new PointF(200, 0);
                    PointF[] ravnostor_Triangle = { point12, point13, point14};
                    g.FillPolygon(brush, ravnostor_Triangle);
                    break;
                case 7:
                    PointF point15 = new PointF(120, 50);
                    PointF point16 = new PointF(20, 50);
                    PointF point17 = new PointF(20, 100);
                    PointF point18 = new PointF(120, 100);
                    PointF[] Restangle = { point15, point16, point17, point18};
                    g.FillPolygon(brush, Restangle);
                    break;
                case 10:
                    PointF point19 = new PointF(30, 80); 
                    PointF point20 = new PointF(80, 80);
                    PointF point21 = new PointF(100, 40); 
                    PointF point22 = new PointF(50, 40);
                    PointF[] Parallelogram = { point19, point20, point21, point22};
                    g.FillPolygon(brush, Parallelogram);
                    break;
                case 3:
                    PointF point23 = new PointF(70, 30);
                    PointF point24 = new PointF(110, 50);
                    PointF point25 = new PointF(70, 70);
                    PointF point26 = new PointF(30, 50);
                    PointF[] Romb = { point23, point24, point25, point26};
                    g.FillPolygon(brush, Romb);
                    break;
                case 11:
                    g.FillEllipse(brush, 90, 90, 40, 60);
                    break;
                case 5:
                    g.DrawEllipse(pen, 80, 80, 40, 40);
                    break;
                case 4:
                    PointF point27 = new PointF(100, 200);
                    PointF point28 = new PointF(200, 100);
                    PointF point29 = new PointF(100, 100);
                    PointF[] Pryamoug_Tiangle = { point27, point28, point29};
                    g.FillPolygon(brush, Pryamoug_Tiangle);
                    break;
                case 2:
                    g.DrawEllipse(pen, 50, 10, 20, 20);
                    
                    PointF point30 = new PointF(60, 90);
                    PointF point31 = new PointF(60, 40);
                    PointF[] Body = { point30, point31};
                    g.DrawPolygon(pen, Body);

                    PointF point32 = new PointF(40, 120);
                    PointF point33 = new PointF(60, 90);
                    PointF[] Left_Foot = { point32, point33 };
                    g.DrawPolygon(pen, Left_Foot);

                    PointF point34 = new PointF(60, 90);
                    PointF point35 = new PointF(80, 120);
                    PointF[] Right_Foot = { point34, point35 };
                    g.DrawPolygon(pen, Right_Foot);

                    PointF point36 = new PointF(60, 30);
                    PointF point37 = new PointF(50, 80);
                    PointF[] Left_Hand = { point36, point37 };
                    g.DrawPolygon(pen, Left_Hand);

                    PointF point38 = new PointF(60, 30);
                    PointF point39 = new PointF(70, 80);
                    PointF[] Right_Hand = { point38, point39 };
                    g.DrawPolygon(pen, Right_Hand);

                    break;


            }

        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            flag = 1;
        }

        private void radioButton12_CheckedChanged(object sender, EventArgs e)
        {
            flag = 2;
        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {
            flag = 3;
        }

        private void radioButton11_CheckedChanged(object sender, EventArgs e)
        {
            flag = 4;
        }

        private void radioButton9_CheckedChanged(object sender, EventArgs e)
        {
            flag = 5;
        }

        private void radioButton10_CheckedChanged(object sender, EventArgs e)
        {
            flag = 6;
        }

        private void radioButton7_CheckedChanged(object sender, EventArgs e)
        {
            flag = 7;
        }

        private void radioButton8_CheckedChanged(object sender, EventArgs e)
        {
            flag = 8;
        }

        private void radioButton5_CheckedChanged(object sender, EventArgs e)
        {
            flag = 9;
        }

        private void radioButton6_CheckedChanged(object sender, EventArgs e)
        {
            flag = 10;
        }

        private void radioButton4_CheckedChanged(object sender, EventArgs e)
        {
            flag = 11;
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            flag = 12;
        }

        private void Button_Back(object sender, EventArgs e)
        {
            Form_Start fr3 = new Form_Start();
            fr3.Show();
            Hide();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (this.WindowState == FormWindowState.Normal)
            {
                this.WindowState = FormWindowState.Maximized;
            }
            else
            {
                this.WindowState = FormWindowState.Normal;
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }
    }
}
