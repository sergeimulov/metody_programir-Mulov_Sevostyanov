﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _20._03._2024_Task02o_Mulov_Sevostyanov
{
    public partial class Form_Start : Form
    {
        public Form_Start()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button_start(object sender, EventArgs e)
        {
            Form_Main fr2 = new Form_Main();
            fr2.Show();
            Hide();
        }

        private void button_Help(object sender, EventArgs e)
        {
            Form_Help fr3 = new Form_Help();
            fr3.Show();
            Hide();
        }

        private void Close_Button(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Min_Button(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void Maxmin_Button(object sender, EventArgs e)
        {
            if (this.WindowState == FormWindowState.Normal)
            {
                this.WindowState = FormWindowState.Maximized;
            }
            else
            {
                this.WindowState = FormWindowState.Normal;
            }

        }
    }
}
